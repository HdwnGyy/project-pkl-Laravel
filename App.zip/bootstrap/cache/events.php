<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\UserSubscribed' => 
    array (
      0 => 'App\\Listeners\\SendSubscriberEmail@handle',
      1 => 'App\\Listeners\\UpdateSubscribersTable@handle',
    ),
  ),
);