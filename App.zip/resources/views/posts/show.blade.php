<x-layout>

    <x-postCard  :post="$post" full/> 

</x-layout>