<h1>Hello <?php echo e($user->username); ?></h1>

<div>
    <h2>You created <?php echo e($post->title); ?></h2>
    <p><?php echo e($post->body); ?></p>

    <img width="300" src="<?php echo e($message->embed('storage/' . $post->image)); ?>" alt="">
</div><?php /**PATH C:\xampp\htdocs\App\resources\views\emails\welcome.blade.php ENDPATH**/ ?>