<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['post', 'full' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['post', 'full' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="card mb-4 p-6 rounded-lg shadow-md bg-white">
    <div class="flex gap-6">
        
        <div class="w-1/3 h-auto rounded-md overflow-hidden flex-shrink-0">
            <?php if($post->image): ?>
                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" alt="" class="card-img">
            <?php else: ?>
                <img class="card-img rounded-md" src="<?php echo e(asset('storage/posts_images/default.jpeg')); ?>" alt="">
            <?php endif; ?>
        </div>

        <div class="w-2/3">
            
            <h2 class="font-bold text-xl"><?php echo e($post->title); ?></h2>

            
            <div class="text-xs font-light mb-4">
                <span>Posted <?php echo e($post->created_at->diffForHumans()); ?> by </span>
                <a href="<?php echo e(route('posts.user', $post->user)); ?>"
                    class="text-blue-500 font-medium"><?php echo e($post->user->username); ?></a>
            </div>

            
            <?php if($full): ?>
                
                <div class="text-sm">
                    <span><?php echo e($post->body); ?></span>
                </div>
            <?php else: ?>
                
                <div class="text-sm">
                    <span><?php echo e(Str::words($post->body, 15)); ?></span>
                    <a href="<?php echo e(route('posts.show', $post)); ?>" class="text-blue-500 ml-2">Read more &rarr;</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    
    <div>
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\App\resources\views\components\postCard.blade.php ENDPATH**/ ?>